import React from 'react'

function ArrayObj() {
    let mahendraDetails={
        firstName:"YADAGIRI ",
        lastName:"MAHENDRA",
        age:22,
        email:"mahendrayadagiri45@gmail.com",
        phoneno:"75679745676",
        family:{
            Mother:"Padmavathi",
            Father:"Srinivasu",
            Brother:"Vamsi"

        }


    };

    let srikanthDetails=[
       "K. ",
       "Srikanth",
       23,
        "srikanth12@gmail.com",
        "7689023452",
        [
            "Parvathi",
            "Siva",
            "Sai"
        ]
    ];

//Objects Destructuring
 let {firstName,lastName,age}=mahendraDetails;
//Arrays Destructuring
let [slastName, sfirstName, sage] = srikanthDetails;



  return (
    <div clasName="border" >
    <div className='side' >
      <h1>Object</h1>
      <h2>Mahendra Details</h2>
      <p>{mahendraDetails.firstName}{mahendraDetails.lastName}</p>
      <p>(Age:{mahendraDetails.age})</p>
      <p>email:{mahendraDetails.email}</p>
      <p>phone-no:{mahendraDetails.phoneno}</p>
      <p><b>Family Details</b></p>
      <p>Mother:{mahendraDetails.family.Mother}</p>
      <p>Father:{mahendraDetails.family.Father}</p>
      <p>Brother:{mahendraDetails.family.Brother}</p>
      </div>

      <div  className='side'>
        <h1>Array</h1>
        <h2>Srikanth Details</h2>
        <p>{srikanthDetails[0]}{srikanthDetails[1]}</p>
        <p>(Age:{srikanthDetails[2]})</p>
        <p>email:{srikanthDetails[3]}</p>
        <p>phone-no:{srikanthDetails[4]}</p>
        <p><b>Family Details</b></p>
        <p>Mother:{srikanthDetails[5][0]}</p>
        <p>Father:{srikanthDetails[5][1]}</p>
        <p>Brother:{srikanthDetails[5][2]}</p>
         </div>
      <hr></hr>
      <div>
        <h3>Object Destructring</h3>
        <p><b>{firstName}{lastName}</b></p>
        <p><b>{age}</b></p>
      </div>
      <hr></hr>
      <div>   
  <h3>Array Destructuring</h3>
  <p><b>{slastName}{sfirstName} </b></p>
  <p><b>Age: {sage}</b></p>
</div>
    
    </div>
    
   
  )
}

export default ArrayObj
