import React from 'react'

let CallBackFn=()=> {
    let calculateStudentResult=(engMarks,telMarks,hinMarks,matMarks,sciMarks,socMarks,passFn,failFn)=>{
        if(engMarks>=35 &&
            telMarks>=35 &&
            hinMarks>=35 &&
            matMarks>=35 &&
            sciMarks>=35 &&
            socMarks>=35 

        ){
            passFn();
        }else{
            failFn();
        }

       
    }
    calculateStudentResult(52,74,96,87,75,69,()=>{
        console.log(`Student Passed in tenth`)
    },()=>{
        console.log(`Student failed in tenth`)
    });

  return (
    <div>
      <h1>Callback Functions</h1>
    </div>
  )
}

export default CallBackFn
