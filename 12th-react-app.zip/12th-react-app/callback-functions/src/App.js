
import './App.css';
import CallBackFn from './components/CallBackFn';
import ArrObj from './components/ArrObj';
import ArrayObj from './components/ArrayObj';

function App() {
  return (
    <div className="App">
      <div className="border">
      <CallBackFn></CallBackFn> 
      <ArrObj></ArrObj> 
      <ArrayObj/>
      </div>
    </div>
  );
}

export default App;
