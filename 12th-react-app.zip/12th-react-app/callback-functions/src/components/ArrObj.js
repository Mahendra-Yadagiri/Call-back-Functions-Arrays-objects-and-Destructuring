import React from 'react'

function ArrObj() {
    // let dhoniFn="M S";
    // let dhoniLn="Dhoni";
    
    let dhoniDetails={
        firstName:"M S",
        lastName:"Dhoni",
        age:52,
        email:"dhoni@gmail.com",
        password:"dhoni123",
        friends:[
            "virat","jadu"
        ],
        family:{
            wife:"Sakshi",
            daughter:"Jeeva"
        }
         
        

    }
    // console.log(dhoniDetails.family.daughter)
    console.log(dhoniDetails.friends[1])

    let viratDetails=["Virat","Kohli",35,["Anushk Sharma","Vamika","son1"],{
       frnd1: "deviliers",frnd2:"Gayel"
    },"virat123@gmail.com","virat@123"];
    console.log(viratDetails[0]);
     console.log(viratDetails[3][1])
    console.log(viratDetails[4].frnd2)

    let {firstName,lastName,age,email}=dhoniDetails;
    // console.log(firstName,lastName,age,email);
    let [fn,ln,age1]=viratDetails
   console.log(fn,ln,age1)


    
  return (
    <div>
      <h1>Array and Object Destructring</h1>
    </div>
  )
}

export default ArrObj
